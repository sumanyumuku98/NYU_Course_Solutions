Author: Sumanyu Muku (smuku@nyu.edu)

By default linserv1 uses gcc version 4.8.5. I am using a different gcc version.

So before running make command, kindly load the compiler gcc-4.9.2. Therefore, add that compiler by following command:
"module load gcc-4.9.2". If you are unable to load gcc-4.9.2, run "module purge" and then again try loading gcc-4.9.2. I haven't tried compiling this code with newer gcc versions.